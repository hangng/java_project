package com.example.n3333.myapplication;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class NameList {

    String name;
    int id;

    public NameList(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }
}
